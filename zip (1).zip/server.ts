import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Spin Logic API
  app.post("/api/spin", (req, res) => {
    const { betAmount } = req.body;
    
    const validBets = [10, 40, 100, 1000];
    if (!validBets.includes(betAmount)) {
      return res.status(400).json({ error: "Invalid bet amount" });
    }

    // 30% chance of winning, 70% chance of losing
    const isWin = Math.random() < 0.30;
    let winAmount = 0;

    if (isWin) {
      switch (betAmount) {
        case 10: winAmount = 10 * 3; break;
        case 40: winAmount = 40 * 7; break;
        case 100: winAmount = 100 * 10; break;
        case 1000: winAmount = 1000 * 100; break;
      }
    }

    res.json({ winAmount });
  });

  // Mock Razorpay Order API
  app.post("/api/razorpay/order", (req, res) => {
    const { amount } = req.body;
    res.json({
      id: "order_" + Math.random().toString(36).substring(7),
      amount: amount * 100,
      currency: "INR"
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
