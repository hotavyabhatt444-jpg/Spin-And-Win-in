import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { collection, query, onSnapshot, doc, updateDoc, increment, orderBy, limit } from "firebase/firestore";
import { db } from "@/src/lib/firebase";
import { Card, CardContent, CardHeader, CardTitle } from "@/src/components/ui/card";
import { Button } from "@/src/components/ui/button";
import { Clock, Activity, Users as UsersIcon, ShieldAlert } from "lucide-react";

export default function Admin({ user, isAdmin }: { user: any, isAdmin: boolean }) {
  const navigate = useNavigate();
  const [users, setUsers] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [recentSpins, setRecentSpins] = useState<any[]>([]);

  useEffect(() => {
    if (!user || !isAdmin) {
      navigate("/");
      return;
    }

    const unsubUsers = onSnapshot(collection(db, "users"), (snap) => {
      setUsers(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    const unsubWithdrawals = onSnapshot(query(collection(db, "withdrawals"), orderBy("createdAt", "desc")), (snap) => {
      setWithdrawals(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    const unsubSpins = onSnapshot(query(collection(db, "spins"), orderBy("createdAt", "desc"), limit(10)), (snap) => {
      setRecentSpins(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    return () => {
      unsubUsers();
      unsubWithdrawals();
      unsubSpins();
    };
  }, [user, isAdmin, navigate]);

  const handleApprove = async (w: any) => {
    try {
      await updateDoc(doc(db, "withdrawals", w.id), { status: "approved" });
    } catch (error) {
      console.error("Error approving", error);
    }
  };

  const handleReject = async (w: any) => {
    try {
      await updateDoc(doc(db, "withdrawals", w.id), { status: "rejected" });
      await updateDoc(doc(db, "users", w.userId), {
        walletBalance: increment(w.amount)
      });
    } catch (error) {
      console.error("Error rejecting", error);
    }
  };

  if (!isAdmin) return null;

  const pendingWithdrawals = withdrawals.filter(w => w.status === "pending");

  return (
    <div className="max-w-7xl mx-auto p-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-red-400 flex items-center gap-2">
        <ShieldAlert className="h-8 w-8" /> Admin Dashboard
      </h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><UsersIcon className="h-5 w-5 text-blue-400"/> Total Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold">{users.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Clock className="h-5 w-5 text-yellow-400"/> Pending Withdrawals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold text-yellow-400">{pendingWithdrawals.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Activity className="h-5 w-5 text-green-400"/> Total Spins</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold text-green-400">{recentSpins.length > 0 ? "Active" : "Idle"}</div>
            <p className="text-xs text-gray-400 mt-1">Live monitoring active</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Pending Withdrawal Requests</CardTitle>
          </CardHeader>
          <CardContent>
            {pendingWithdrawals.length === 0 ? (
              <p className="text-gray-500">No pending requests.</p>
            ) : (
              <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
                {pendingWithdrawals.map(w => {
                  const u = users.find(user => user.uid === w.userId);
                  return (
                    <div key={w.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10 gap-4">
                      <div>
                        <p className="font-medium">{u?.name || 'Unknown User'} ({u?.email})</p>
                        <p className="text-sm text-gray-400">Amount: <span className="text-primary font-bold">₹{w.amount}</span></p>
                        <p className="text-sm text-gray-400">UPI: <span className="text-white">{w.upiId}</span></p>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="border-green-500 text-green-500 hover:bg-green-500/20" onClick={() => handleApprove(w)}>Approve</Button>
                        <Button size="sm" variant="outline" className="border-red-500 text-red-500 hover:bg-red-500/20" onClick={() => handleReject(w)}>Reject</Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Live Spin Activity</CardTitle>
          </CardHeader>
          <CardContent>
            {recentSpins.length === 0 ? (
              <p className="text-gray-500">No recent spins.</p>
            ) : (
              <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                {recentSpins.map(spin => {
                  const u = users.find(user => user.uid === spin.userId);
                  return (
                    <div key={spin.id} className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/10">
                      <div>
                        <p className="font-medium text-sm">{u?.name || 'Unknown User'}</p>
                        <p className="text-xs text-gray-400">{new Date(spin.createdAt).toLocaleTimeString()}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-gray-400">Bet: ₹{spin.cost}</p>
                        <p className={`text-sm font-bold ${spin.winAmount > 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {spin.winAmount > 0 ? `Won ₹${spin.winAmount}` : 'Lost'}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>User Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-gray-400 uppercase bg-white/5">
                <tr>
                  <th className="px-4 py-3 rounded-tl-lg">Name</th>
                  <th className="px-4 py-3">Email</th>
                  <th className="px-4 py-3">Balance</th>
                  <th className="px-4 py-3">Referral Code</th>
                  <th className="px-4 py-3">Joined</th>
                  <th className="px-4 py-3 rounded-tr-lg">Last Known UPI</th>
                </tr>
              </thead>
              <tbody>
                {users.map(u => {
                  // Find last withdrawal for UPI
                  const userWithdrawals = withdrawals.filter(w => w.userId === u.uid);
                  const lastUpi = userWithdrawals.length > 0 ? userWithdrawals[0].upiId : 'N/A';
                  
                  return (
                    <tr key={u.id} className="border-b border-white/5 hover:bg-white/5">
                      <td className="px-4 py-3 font-medium">{u.name} {u.role === 'admin' && <span className="ml-2 text-xs bg-red-500/20 text-red-400 px-2 py-0.5 rounded">ADMIN</span>}</td>
                      <td className="px-4 py-3 text-gray-400">{u.email}</td>
                      <td className="px-4 py-3 text-primary font-bold">₹{u.walletBalance?.toFixed(2) || 0}</td>
                      <td className="px-4 py-3 font-mono text-gray-400">{u.referralCode}</td>
                      <td className="px-4 py-3 text-gray-400">{new Date(u.createdAt).toLocaleDateString()}</td>
                      <td className="px-4 py-3 text-gray-400">{lastUpi}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
